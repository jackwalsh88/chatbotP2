# Phase 2 handoff — avatar-derived character persona

Everything needed to review, run and continue the Phase 2 work. Nothing here
requires access to the `jackwalsh88` GitHub account.

## What is in this zip

| File | What it is |
|---|---|
| `PHASE2-PERSONA-HANDOFF.md` | **Read this first.** What the feature does, what it deliberately leaves alone, the six decisions worth disagreeing with, what was verified live and what was not. |
| `LOCAL-SETUP.md` | Getting it running on a fresh machine, including the four traps that cost time. |
| `phase2-commits.patch` | The 13 Phase 2 commits as a patch series — every diff and every commit message, readable without git. |
| `source/` | The code as a plain directory, for browsing or grepping. |

Two things are deliberately **not** in here, both for size:

- **Git history.** One command gets it (below); a bundle of it is 46 MB.
- **Character media** (`apps/web/public/media/`) — ~43 MB of video, byte-identical
  to Phase 1. `source/` will run but render broken images until you supply it,
  either by cloning below or by copying the directory out of Over18.

## Get the repository

The repo is public, so this needs no credentials:

```bash
git clone https://github.com/jackwalsh88/chatbotP2.git
cd chatbotP2
git checkout claude/phase-2-development-xpwu42
```

Two branches matter:

- `claude/phase-2-development-xpwu42` — the Phase 2 work
- `origin/phase-1-baseline` — Phase 1 untouched, as the comparison point.
  It exists only so the diff below is exactly Phase 2 and nothing else.

```bash
# the entire Phase 2 diff, and nothing else
git diff origin/phase-1-baseline..HEAD

# the 13 commits, with the reasoning in each message
git log --oneline origin/phase-1-baseline..HEAD
```

Same diff as pull request #1, if you would rather read it in a browser:
https://github.com/jackwalsh88/chatbotP2/pull/1

Without git, `phase2-commits.patch` carries the identical content, and
`git apply` or `git am` will replay it onto a Phase 1 checkout.

## The three commits that change behaviour

Everything else is new files or additive. These three alter how the product
behaves and deserve the closest reading:

- **`fdfc4a2`** — with richer identity data in `WHO SHE IS`, Luna opened by
  reciting her whole profile. This adds an anti-recital rule. It rests on
  exactly one live reply. Treat it as unproven.
- **`a86dff3`** — reply length keyed to relationship stage rather than a fixed
  cap. The `conversationStage()` thresholds (4 and 20 prior messages) are
  guesses, not measurements.
- **`6e74183`** — per-field auto-apply writes generated values into *empty*
  `characters` columns without review; non-empty fields still require an
  operator to accept. This is the only place Phase 2 writes to a Phase 1 table.

`8a7f634` is the `prompt-builder.ts` integration. With no persona row stored,
the compiler calls return empty and prompt output is byte-identical to Phase 1
— `prompt-builder.test.ts` and `llm.test.ts` pass unmodified. One real output
change: a character with no `VOICE_DIALS` entry but a generated persona now
gets a `HER VOICE` section for the first time. Intended, but worth knowing.

## What is not verified

- **`character-persona-service.test.ts` has never executed.** No Postgres was
  available in the build environment. It is written against the same harness as
  `visual-identity.test.ts` and needs one run against a `*_test` database.
  This is the single highest-value thing to do first.
- **The comparative evaluation was never run.** Nobody has measured
  persona-generated replies against no-persona replies. The premise that this
  fixes "generic" replies is still a premise.

## Two things needing a decision, not code

1. **Where this lives.** It is currently a branch in a scratch repo
   (`jackwalsh88/chatbotP2`) built from an import of `NewMotive8/Over18` @
   `epic-11-ops`. It has to be ported into Over18, adopted there, or declared a
   throwaway prototype. Nothing was pushed to Over18.
2. **The API key.** The xAI key used for local testing was pasted into a chat
   transcript and should be rotated. Use your own for local work; do not reuse
   the one in any config you are handed.

Section 7 of the handoff document lists the remaining open decisions.
