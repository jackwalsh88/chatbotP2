# Running it locally

Verified end to end on Windows (PowerShell) against real Postgres and live
Grok. macOS/Linux differs only in the shell syntax.

Prerequisites: Node 20+, Docker, git.

## 1. Database

```bash
docker run -d --name over18-db \
  -e POSTGRES_USER=over18 \
  -e POSTGRES_PASSWORD=over18_local_dev \
  -e POSTGRES_DB=over18 \
  -p 5432:5432 postgres:16
```

## 2. `apps/api/.env`

```
DATABASE_URL=postgresql://over18:over18_local_dev@127.0.0.1:5432/over18
LLM_BASE_URL=https://api.x.ai/v1
LLM_MODEL=grok-4.20-0309-non-reasoning
LLM_API_KEY=<your own xai key>
LLM_TIMEOUT_MS=60000
PERSONA_VISION_MODEL=grok-4.6
PERSONA_VISION_TIMEOUT_MS=120000
```

Use your own key. The one used during development was exposed in a chat
transcript and should be treated as burned.

## 3. Migrate, seed, run

```bash
npm ci
npm run db:migrate -w @over18/api
npm run db:seed -w @over18/api
npm run dev
```

Admin UI: http://localhost:5173/admin/characters → pick a character →
**Life details from her photo** → **Generate from photo**.

## 4. Tests

```bash
npm test -w @over18/api    # needs TEST_DATABASE_URL pointing at a *_test db
npm test -w @over18/web
```

Tests refuse to run unless the database name ends in `_test`. Expect ~9
pre-existing environmental failures (ffprobe / Windows paths) that predate
Phase 2.

`character-persona-service.test.ts` has never been executed — see the handoff
document. Running it is the first thing worth doing.

---

## The four traps

Three of these are now fixed in the branch and are listed here only so the
symptoms are recognisable if they resurface. The fourth is a live footgun.

1. **`.env` written to the wrong path.** Writing `apps/api/.env` from a shell
   already inside `apps/api` creates `apps/api/apps/api/.env`. The server then
   starts fine and silently ignores every setting — the visible symptom was
   chat timing out at exactly 30034 ms, because `LLM_TIMEOUT_MS` never applied
   and the 30s default was in force. If a setting appears to have no effect,
   check where the file actually landed first.

2. **`grok-4.6` is too slow for chat** (fixed by config, not code). It exceeds
   a 30s timeout and returns a 502 `ai_unavailable`. The non-reasoning variant
   answered the same request in 0.5s. Reasoning models are wrong where latency
   is the product. Persona generation is a background operation, so it can
   afford the slower model — hence the `PERSONA_VISION_*` split.

3. **`npm run db:seed` silently did nothing on Windows** (fixed in `5859b47`).
   The entrypoint guard compared `import.meta.url` to `process.argv[1]` without
   normalising, which never matches on Windows. Exit code 0, no output, no rows.

4. **`npm run dev` failed on `@over18/shared`** (fixed in `f98064f`). The web
   and api dev servers import the shared package but nothing built it first. A
   `predev` script now does.

Also worth knowing, on Windows specifically: PowerShell's execution policy
blocks npm outright until changed, and `npm ci`'s `allow-scripts` approval
prompt only retained one entry per run — editing `package.json` directly was
faster than fighting it.
